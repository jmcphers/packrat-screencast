`euclidean` <-
function(x,y) 
{
  euc <- sqrt(sum((x-y)^2))
  return(euc)
}

