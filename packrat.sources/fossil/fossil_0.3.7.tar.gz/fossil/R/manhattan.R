`manhattan` <-
function(x,y) 
{
  man <- sum(abs(x-y))
  return(man)
}

